function f({x, y}) { "use strict"; }
