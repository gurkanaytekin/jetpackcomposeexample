try {} catch ([a,a]) {}
