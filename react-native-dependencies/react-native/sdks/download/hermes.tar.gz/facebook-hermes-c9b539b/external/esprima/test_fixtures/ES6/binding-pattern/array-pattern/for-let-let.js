for (let [x = let];;) {}
