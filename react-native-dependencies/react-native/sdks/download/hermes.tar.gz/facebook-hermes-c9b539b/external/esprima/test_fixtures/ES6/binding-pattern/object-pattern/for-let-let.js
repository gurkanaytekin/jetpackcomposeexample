for (let {x: y = let};;) {}
