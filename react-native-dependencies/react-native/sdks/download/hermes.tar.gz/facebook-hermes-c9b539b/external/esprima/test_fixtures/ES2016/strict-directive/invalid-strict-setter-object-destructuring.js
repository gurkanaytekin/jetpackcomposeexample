({ set f({a}) { "use strict" } })
