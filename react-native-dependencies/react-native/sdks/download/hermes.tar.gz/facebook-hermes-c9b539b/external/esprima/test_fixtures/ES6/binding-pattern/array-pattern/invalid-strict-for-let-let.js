"use strict"; for (let [x = let];;) {}
