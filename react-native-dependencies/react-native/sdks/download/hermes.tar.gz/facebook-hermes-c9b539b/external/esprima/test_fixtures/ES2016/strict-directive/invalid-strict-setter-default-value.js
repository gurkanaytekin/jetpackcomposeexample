({ set f(a = 1) { "use strict" } })
