let [...[x]] = y
