function *g(a = 1){ "use strict"; }
