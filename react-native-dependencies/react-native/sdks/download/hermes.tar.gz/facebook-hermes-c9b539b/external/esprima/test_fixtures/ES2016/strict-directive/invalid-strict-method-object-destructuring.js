class X { f({a}) { "use strict" } }
