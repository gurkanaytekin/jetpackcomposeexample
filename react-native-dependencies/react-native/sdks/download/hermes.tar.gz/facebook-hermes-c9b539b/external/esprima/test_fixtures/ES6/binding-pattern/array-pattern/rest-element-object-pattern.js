var [...{x}] = y
