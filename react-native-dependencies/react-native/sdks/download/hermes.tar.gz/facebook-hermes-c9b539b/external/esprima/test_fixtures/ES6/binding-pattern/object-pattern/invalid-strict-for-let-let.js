"use strict"; for (let {x: y = let};;) {}
